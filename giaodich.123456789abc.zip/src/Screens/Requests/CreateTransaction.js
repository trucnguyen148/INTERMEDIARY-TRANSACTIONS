import React, {Component} from 'react';

class CreateTransaction extends Component{
    render(){
        return(
            <div>
                <h1>CreateTransaction</h1>
            </div>
        )
    }
}

export default CreateTransaction