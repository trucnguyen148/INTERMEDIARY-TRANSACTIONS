import React, {Component} from 'react';

class SendRequest extends Component{
    render(){
        return(
            <div>
                <h1>SendRequest</h1>
            </div>
        )
    }
}

export default SendRequest