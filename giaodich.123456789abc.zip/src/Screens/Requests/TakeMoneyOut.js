import React, {Component} from 'react';

class TakeMoneyOut extends Component{
    render(){
        return(
            <div>
                <h1>TakeMoneyOut</h1>
            </div>
        )
    }
}

export default TakeMoneyOut