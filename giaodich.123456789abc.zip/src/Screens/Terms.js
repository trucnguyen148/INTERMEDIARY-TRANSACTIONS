import React, {Component} from 'react';

class Terms extends Component{
    render(){
        return(
            <div>
                <h1>Terms</h1>
            </div>
        )
    }
}

export default Terms