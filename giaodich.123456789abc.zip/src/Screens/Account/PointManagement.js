import React, {Component} from 'react';

class PointManagement extends Component{
    render(){
        return(
            <div>
                <h1>PointManagement</h1>
            </div>
        )
    }
}

export default PointManagement