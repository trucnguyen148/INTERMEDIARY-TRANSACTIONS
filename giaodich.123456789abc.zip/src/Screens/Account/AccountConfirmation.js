import React, {Component} from 'react';

class AccountConfirmation extends Component{
    render(){
        return(
            <div>
                <h1>AccountConfirmation</h1>
            </div>
        )
    }
}

export default AccountConfirmation