import React, {Component} from 'react';

class BasicInformation extends Component{
    render(){
        return(
            <div>
                <h1>BasicInformation</h1>
            </div>
        )
    }
}

export default BasicInformation