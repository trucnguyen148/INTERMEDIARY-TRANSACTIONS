import React, {Component} from 'react';

class HistoryPoint extends Component{
    render(){
        return(
            <div>
                <h1>HistoryPoint</h1>
            </div>
        )
    }
}

export default HistoryPoint