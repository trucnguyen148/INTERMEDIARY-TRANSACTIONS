import React, {Component} from 'react';

class RequestingTransaction extends Component{
    render(){
        return(
            <div>
                <h1>RequestingTransaction</h1>
            </div>
        )
    }
}

export default RequestingTransaction