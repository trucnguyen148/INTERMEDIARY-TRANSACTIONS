import React, {Component} from 'react';

class AccountInformation extends Component{
    render(){
        return(
            <div>
                <h1>AccountInformation</h1>
            </div>
        )
    }
}

export default AccountInformation