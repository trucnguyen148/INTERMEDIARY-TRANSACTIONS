import React, {Component} from 'react';

class Register extends Component{
    render(){
        return(
            <div>
                <h1>Register</h1>
            </div>
        )
    }
}

export default Register