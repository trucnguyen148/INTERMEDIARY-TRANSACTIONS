import React, { Component } from 'react';

import Routes from './Routes/Routes';

export default class App extends Component {

  render(){
    return (
      <Routes/>
    );
  }
}


